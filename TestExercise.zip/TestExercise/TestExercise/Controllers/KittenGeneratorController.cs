﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TestExercise.Services;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System;
using System.Drawing.Imaging;
using TestExercise.Models.Enum;
using System.ComponentModel.DataAnnotations;

namespace TestExercise.Controllers
{
    [Authorize(AuthenticationSchemes = "CookieAuthentication,BasicAuthentication")]
    [ApiVersion("1.0")]
    [ApiController]
    [Route("api")]
    public class KittenGeneratorController : ControllerBase
    {
        private readonly IKittenGeneratorService _kittenGeneratorService;
        private readonly IConfiguration _configuration;
        public KittenGeneratorController(IKittenGeneratorService kittenGeneratorService, IConfiguration configuration)
        {
            _kittenGeneratorService = kittenGeneratorService;
            _configuration = configuration;
        }

        /// <summary>
        /// Get upside down kitten
        /// </summary>
        /// <returns>Result</returns>
        /// <response code="200">Success</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("UpsideDownKittenGenerator")]
        [HttpGet]
        public IActionResult GetUpsideDownKittenGenerator()
        {
            using var webClient = new WebClient();
            var data = webClient.DownloadData(string.Format("{0}/cat", _configuration["CATAAS_URL"]));
            var result = _kittenGeneratorService.FlipImage(data, ImageFormat.Jpeg);
            return File(result, "image/jpeg");
        }

        /// <summary>
        /// Get upside down kitten
        /// </summary>
        /// <param name="tag">tag</param>
        /// <returns>Result</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Bad request</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("UpsideDownKittenGeneratorWithTag")]
        [HttpGet]
        public IActionResult GetUpsideDownKittenGeneratorWithTag([Required] string tag)
        {
            using var webClient = new WebClient();
            var tagsResponse = webClient.DownloadString(string.Format("{0}/api/tags", _configuration["CATAAS_URL"]));
            tagsResponse = tagsResponse.Substring(1, tagsResponse.Length - 2);
            var tags = tagsResponse.Split(",").Select(x => x.Trim('"'));
            if (tags.Contains(tag, StringComparer.OrdinalIgnoreCase))
            {
                var data = webClient.DownloadData(string.Format("{0}/cat/{1}", _configuration["CATAAS_URL"], tag));
                var result = _kittenGeneratorService.FlipImage(data, ImageFormat.Jpeg);
                return File(result, "image/jpeg");
            }

            return BadRequest("Invalid tag");
        }

        /// <summary>
        /// Get upside down kitten with type
        /// </summary>
        /// <param name="imageType">Image type</param>
        /// <returns>Result</returns>
        /// <response code="200">Success</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("UpsideDownKittenGeneratorWithType")]
        [HttpGet]
        public IActionResult GetUpsideDownKittenGeneratorWithType([Required] ImageType imageType)
        {
            using var webClient = new WebClient();
            var data = webClient.DownloadData(string.Format("{0}/cat?type={1}", _configuration["CATAAS_URL"], imageType));
            var result = _kittenGeneratorService.FlipImage(data, ImageFormat.Jpeg);
            return File(result, "image/jpeg");
        }
    }
}