﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TestExercise.Models;
using TestExercise.Services;

namespace TestExercise.Controllers
{
    [ApiVersion("1.0")]
    [Route("api")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IMapper _mapper;

        public UserController(IUserService userService, IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        /// <summary>
        /// Register user
        /// </summary>
        /// <param name="model">Register user model</param>
        /// <returns>Register status</returns>
        /// <response code="200">Success</response>
        /// <response code="409">Conflict</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("Register")]
        [HttpPost]
        public IActionResult Register([FromBody] RegisterUserModel model)
        {
            var user = _mapper.Map<User>(model);
            var result = _userService.Create(user, model.Password);

            if (result == null)
            {
                return Conflict("Username already exists");
            }

            return Ok();
        }

        /// <summary>
        /// Get user details based on first name and last name
        /// </summary>
        /// <param name="firstName">First name</param>
        /// <param name="lastName">Last name</param>
        /// <returns>User</returns>
        /// <response code="200">Success</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("GetUserByName")]
        [HttpGet]
        public IActionResult GetUserByName(string firstName, string lastName)
        {
            var user = _userService.GetByName(firstName, lastName);

            if (user == null)
                return NotFound("User not found");

            var model = _mapper.Map<UserModel>(user);
            return Ok(model);
        }

        /// <summary>
        /// User login
        /// </summary>
        /// <param name="model">Authentication model</param>
        /// <returns>Login status</returns>
        /// <response code="200">Success</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("Login")]
        [HttpPost]
        public IActionResult Login([FromBody] AuthenticateModel model)
        {
            var user = _mapper.Map<AuthenticateModel>(model);

            if (_userService.Authenticate(model.Username, model.Password))
            {
                var claimsIdentity = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, user.Username),
                }, "CookieAuthentication");

                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                Request.HttpContext.SignInAsync("CookieAuthentication", claimsPrincipal).Wait();

                return Ok();
            }
            else
            {
                return Unauthorized();
            }
        }

        /// <summary>
        /// User logout
        /// </summary>
        /// <returns>Logout status</returns>
        /// <response code="200">Success</response>
        /// <response code="500">Internal server error</response>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("LogOut")]
        [HttpPost]
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync("CookieAuthentication");

            return Ok();
        }
    }
}