﻿using Microsoft.AspNetCore.Identity;

namespace TestExercise.Models
{
    public class User : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public new byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
    }
}
