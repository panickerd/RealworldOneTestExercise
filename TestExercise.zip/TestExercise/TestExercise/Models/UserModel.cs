﻿namespace TestExercise.Models
{
    public class UserModel
    {
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public string Username { get; set; }
    }
}
