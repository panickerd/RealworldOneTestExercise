﻿namespace TestExercise.Models.Enum
{
    public enum ImageType
    {
        small,
        medium,
        square,
        original
    }
}
