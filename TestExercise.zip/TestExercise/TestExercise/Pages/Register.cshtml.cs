using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TestExercise.Models;
using TestExercise.Services;

namespace TestExercise.Pages
{
    public class RegisterModel : PageModel
    {
        public RegisterUserModel model;
        [ViewData]
        public string Message { get; set; }
        private readonly IUserService _userService;
        private readonly IMapper _mapper;

        public RegisterModel(IUserService userService,
            IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        public IActionResult OnPost(RegisterUserModel model)
        {
            if (!ModelState.IsValid)
            {
                return null;
            }

            var user = _mapper.Map<User>(model);
            if (_userService.Create(user, model.Password) != null)
            {
                return RedirectToPage("Index");
            }

            Message = "Username already exists";
            return null;
        }
    }
}
