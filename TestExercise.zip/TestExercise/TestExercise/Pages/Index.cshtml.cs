﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using System.Threading.Tasks;
using TestExercise.Models;
using TestExercise.Services;

namespace TestExercise.Pages
{
    public class IndexModel : PageModel
    {
        public AuthenticateModel Model { get; set; }
        [ViewData]
        public string Message { get; set; }
        private readonly ILogger<IndexModel> _logger;
        private readonly IMapper _mapper;
        private readonly IUserService _userService;

        public IndexModel(ILogger<IndexModel> logger, IUserService userService, IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
            _userService = userService;
        }

        public async Task<IActionResult> OnPost(AuthenticateModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _mapper.Map<AuthenticateModel>(model);

                if (_userService.Authenticate(model.Username, model.Password))
                {
                    var claimsIdentity = new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.Name, user.Username),
                    }, "CookieAuthentication");

                    var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                    await Request.HttpContext.SignInAsync("CookieAuthentication", claimsPrincipal);

                    return Redirect("/swagger");
                }
                else
                {
                    Message = "Invalid credentials";
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
    }
}
