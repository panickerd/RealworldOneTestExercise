﻿using Microsoft.EntityFrameworkCore;
using TestExercise.Models;

namespace TestExercise.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }
}
