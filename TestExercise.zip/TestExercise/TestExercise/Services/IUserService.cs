﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestExercise.Models;

namespace TestExercise.Services
{
    public interface IUserService
    {
        bool Authenticate(string username, string password);
        IEnumerable<User> GetAll();
        User GetByName(string firstName, string lastName);
        User Create(User user, string password);
        void Delete(int id);
    }
}
