﻿using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace TestExercise.Services.Implementation
{
    public class KittenGeneratorService : IKittenGeneratorService
    {
        public byte[] FlipImage(byte[] data, ImageFormat imageFormat)
        {
            using var ms = new MemoryStream(data);
            var image = Image.FromStream(ms);
            image.RotateFlip(RotateFlipType.Rotate180FlipNone);

            using var resultms = new MemoryStream();
            image.Save(resultms, imageFormat);
            return resultms.ToArray();
        }
    }
}
