﻿using System.Drawing.Imaging;

namespace TestExercise.Services
{
    public interface IKittenGeneratorService
    {
        byte[] FlipImage(byte[] data, ImageFormat imageFormat);
    }
}
