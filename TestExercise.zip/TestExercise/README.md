# Introduction and usage
1. User registeration and login can be performed using razor pages or swagger UI. 
   By default, user login page is displayed. As we use im-memory database, user needs to register before login. 
   Once user is successfully logged-in, application will redirect to swagger UI.
   Swagger UI can be navigated from menu link.
2. The endpoints related to KittenGenerator will require authentication to authorize its use. 
   Bearer token authentication or user login can be used as both cookie authentication and basic authentication schemes are supported.
   The credentials for bearer token can be found in appSettings file.
3. We could add unit test project in future for code coverage and TDD.